# print '****************************************' begin .zshenv $PWD

Z=~/.zshrc
ZS=${Z}s
X=~/.vimrc

c=$PWD

home_bin=${HOME}/.bin

PATH+=":${home_bin}"
PATH+=:/usr/local/bin
PATH+=:/bin:/sbin:/usr/bin:/usr/sbin

export AWKSCRIPT=~/.awkscript
export DIRS=~/.dirs
export DOWN=~/Downloads
export PERLSCRIPT=~/.perlscript
export SEDSCRIPT=~/.sedscript
export TRASH=$HOME/.local/share/Trash/files

# formato de salida del comando time
export TIMEFMT=$'\n================\nCPU\t%P\nuser\t%U\nsystem\t%S\ntotal\t%E'

functionsZSH=$HOME/.functionsZSH
fpath=($functionsZSH $fpath)
cd $functionsZSH
for i in *
do
  autoload $i
done

o=/tmp/out
o2=/tmp/out2

cd "$c"

# print '****************************************' end .zshenv $PWD
