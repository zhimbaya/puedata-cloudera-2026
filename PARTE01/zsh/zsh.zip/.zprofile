# print '****************************************' begin .zprofile $PWD

# print '****************************************' end .zprofile $PWD
