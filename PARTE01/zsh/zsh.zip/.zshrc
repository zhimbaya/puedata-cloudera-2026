# print '****************************************' begin .zshrc $PWD

umask 0022

# `no` máquina virtual remota.  `yes` Mac
export LOCAL=no
#
# ***************************************************** Teclas
#
# equivalente a set -o vi
bindkey -v

# ESC-. inserta la última palabra del comando anterior
bindkey '' beginning-of-line
bindkey '' end-of-line
bindkey '' insert-last-word
bindkey -M viins 'jk' vi-cmd-mode # jk => ESC
bindkey -M viins 'jj' vi-cmd-mode # jk => ESC

# espera 50/100 segundos después del ESC
export KEYTIMEOUT=50
#
# ***************************************************** PROMPT
#
# PROMPT es lo mismo que PS1
nl=$'\n'
export PROMPT="${nl}  %*${nl}  %~${nl}  %! training ▶ "
#
# ***************************************************** history
#
#  path/location of the history file
HISTFILE=$HOME/.zsh_history

# number of commands that are loaded into memory from the history file
HISTSIZE=100

# number of commands that are stored in the zsh history file
SAVEHIST=100
#
# ***************************************************** exports
#
export EDITOR=vi

# Para que el comando ls saque colores.
# CLICOLOR=on => pone colores
# LSCOLORS="exfxcxdxbxegedabagacad" =>
#                        foreground/background
#   ex -> directorio:    azul/omisión
#   fx -> symbolic link: magenta/omisión
# Bx => executable: foreground en rojo (B), background omisión (x)

# Orden de atributos
#   1.  directory
#   2.  symbolic link
#   3.  socket
#   4.  pipe
#   5.  executable
#   6.  block special
#   7.  character special
#   8.  executable with setuid bit set
#   9.  executable with setgid bit set
#   10. directory writable to others, with sticky bit
#   11. directory writable to others, without sticky bit

# Colores:
#   a  black
#   b  red
#   c  green
#   d  brown
#   e  blue
#   f  magenta
#   g  cyan
#   h  light grey
#   A  bold black, usually shows up as dark grey
#   B  bold red
#   C  bold green
#   D  bold brown, usually shows up as yellow
#   E  bold blue
#   F  bold magenta
#   G  bold cyan
#   H  bold light grey; looks like bright white
#   x  default foreground or background

export CLICOLOR=on
export LSCOLORS="exfxcxdxbxegedabagacad"

llf () { /bin/ls -lo "$@" | /usr/bin/less -X --quit-at-eof ; }
lalf () { /bin/ls -lAo "$@" | /usr/bin/less -X --quit-at-eof ; }
lslf () { /bin/ls "$@" | /usr/bin/less -X --quit-at-eof ; }
ls1f () { /bin/ls -1 "$@" | /usr/bin/less -X --quit-at-eof ; }
ltrf () { /bin/ls -ltr "$@" | /usr/bin/less -X --quit-at-eof ; }


#
# ***************************************************** sources
#
for z in zalias zopts zhdfs ; do
  zfile=$HOME/.${z}
  if [[ -f ${zfile} ]] ; then
    source ${zfile}
  fi
done

#
# ***************************************************** cambiar a directorios
# Salvar nombres de directorios en variables para luego hacer cd a ellos.
# Luego nos moveremos usando cd con la abreviaci'on
dirs=~/.dirs
touch ${dirs}

# Quita una entrada
unsave () {
	sed "/$1=/d" ${dirs} >${dirs}1
	\mv ${dirs}1 ${dirs}
	source ${dirs}
}

# Crea una entrada borrando la anterior
# Si no se pasa argumentos se toma como valor el nombre
#    del propio directorio
save () {
	if (( $# == 0 )) ; then
    # $1 <--- la última parte del directorio actual
    set -- $(basename "$PWD")
  elif (( $# > 1 )) ; then
    print has pasado más de un argumento, sólo se toma en cuenta \`$1\`
  fi
	unsave $1
	print "$1"=\"$(pwd)\" >> ${dirs}
	sort -o${dirs} ${dirs}
	source ${dirs}
}

# Lee las definiciones del fichero:
source ${dirs}

# print '****************************************' end .zshrc $PWD
