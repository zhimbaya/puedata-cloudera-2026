USE exam ;

SELECT
  empno, ename, deptno, sal,
  sal - MIN(sal) OVER (PARTITION BY deptno) AS diff_min
FROM emp ;
