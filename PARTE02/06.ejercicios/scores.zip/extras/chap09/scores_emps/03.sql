USE exam ;

SELECT name, test, score,
  AVG(score) OVER (PARTITION BY name) AS avgname
FROM test_scores
ORDER BY name, test ;

