USE exam ;

SELECT
  empno, ename, deptno, sal,
  MIN(sal) OVER (PARTITION BY deptno ) AS min_dept_sal
FROM emp ;

