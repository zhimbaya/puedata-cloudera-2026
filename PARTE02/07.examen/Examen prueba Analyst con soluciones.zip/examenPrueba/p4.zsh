#!/bin/zsh
sqoop import \
  -m 1 \
  --connect jdbc:mysql://localhost/analyst_dualcore \
  --username training --password training \
  --fields-terminated-by ':' \
  --warehouse-dir /tmp \
  --columns "emp_id, fname, lname, city, state" \
  --where "state='OR' AND fname LIKE 'An%'" \
  --delete-target-dir \
  --outdir /tmp \
  --table employees
