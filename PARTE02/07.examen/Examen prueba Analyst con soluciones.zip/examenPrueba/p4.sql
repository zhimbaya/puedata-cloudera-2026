USE exam ;

DROP TABLE IF EXISTS employees ;

CREATE EXTERNAL TABLE employees (
  emp_id STRING,
  fname STRING,
  lname STRING,
  city STRING,
  state CHAR(2)
)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ':'
STORED AS TEXTFILE
LOCATION '/tmp/employees' ;

SELECT * FROM employees
ORDER BY lname
LIMIT 10 ;

SELECT COUNT(1) cnt FROM employees ;
