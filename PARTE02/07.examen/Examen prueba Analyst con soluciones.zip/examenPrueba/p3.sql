USE analyst ;

WITH ads_count AS (
  SELECT display_site, display_date, COUNT(display_date) AS num
  FROM ads
  GROUP BY display_site, display_date
)
SELECT display_site, display_date, num
FROM (
  SELECT display_site, display_date, num,
         rank() OVER (PARTITION BY display_date ORDER BY num ) AS dayrank
  FROM ads_count
  ORDER BY display_date, dayrank) sq
WHERE dayrank = 1
ORDER BY display_date, display_site ;
