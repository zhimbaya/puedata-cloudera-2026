USE exam ;

SELECT
  name, test, score,
  AVG(score) OVER (PARTITION BY test ) avg,
  CASE
    WHEN score > AVG(score) OVER (PARTITION BY test ) THEN "Above"
    ELSE '----'
  END AS 'Above?'
FROM test_scores
ORDER BY test, score DESC

