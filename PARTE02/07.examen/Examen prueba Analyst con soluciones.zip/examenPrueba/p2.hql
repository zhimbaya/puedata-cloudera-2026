USE exam ;

DROP TABLE IF EXISTS customers ;

CREATE EXTERNAL TABLE customers (
  cust_id INT,
  name STRING,
  phones MAP<STRING, STRING>,
  address STRUCT<
    street:STRING,
    city:STRING,
    zipcode:STRING>
)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
  COLLECTION ITEMS TERMINATED BY '*'
  MAP KEYS TERMINATED BY '/'
STORED AS TEXTFILE
LOCATION '/tmp/customers' ;

!sh hdfs dfs -put -f customers.data /tmp/customers

-- SELECT * FROM customers ;

-- SELECT name, p.key AS type, p.value AS number
-- FROM customers
--   LATERAL VIEW explode( phones ) p ;

-- SELECT name, address.street, address.zipcode, p.key AS type, p.value AS number
-- FROM customers
--   LATERAL VIEW explode( phones ) p ;

-- SELECT name, address.street, address.city, p.key AS type, p.value AS number
-- FROM customers
--   LATERAL VIEW explode( phones ) p
-- WHERE address.city LIKE '%l%' ;

SELECT name, address.street, address.city, p.key AS type, p.value AS number
FROM customers
  LATERAL VIEW OUTER explode( phones ) p
ORDER BY name, type;
