DROP TABLE IF EXISTS analyst.latlon;

CREATE EXTERNAL TABLE analyst.latlon 
  LIKE PARQUET '/analyst/dualcore/latlon/part-m-000000_0.parquet' 
  STORED AS PARQUET 
  LOCATION '/analyst/dualcore/latlon';  
