#!/bin/bash

hdfs dfs -cat /analyst/dualcore/ad_data1/* | head -n 5
hdfs dfs -cat /analyst/dualcore/ad_data2/* | head -n 5
