ALTER TABLE analyst.ads ADD PARTITION (network=1);
ALTER TABLE analyst.ads ADD PARTITION (network=2);

LOAD DATA INPATH '/analyst/dualcore/ad_data1' 
  INTO TABLE analyst.ads
  PARTITION(network=1);
  
LOAD DATA INPATH '/analyst/dualcore/ad_data2' 
  INTO TABLE analyst.ads
  PARTITION(network=2);
