USE analyst ;
SELECT COUNT(*) FROM ads WHERE network=1 ;
SELECT COUNT(*) FROM ads WHERE network=2 ;
