SELECT steps_completed, AVG(total_price - total_cost) AS avg_profit
FROM analyst.cart_shipping 
GROUP BY steps_completed;
