SELECT SUM(total_price - total_cost) AS profit
FROM analyst.cart_shipping 
WHERE steps_completed = 4;
