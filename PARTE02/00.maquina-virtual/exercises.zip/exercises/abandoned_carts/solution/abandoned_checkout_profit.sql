SELECT SUM(total_price - total_cost) AS lost_profit
FROM analyst.cart_shipping 
WHERE steps_completed < 4;
