-- This will not run in Hive because the GROUP BY clause
-- uses an alias from the SELECT list. Use Impala to run
-- this query.

SELECT case 
         when total_price <= 1000 then 'up to $10'
         when total_price <= 5000 then 'over $10 up to $50'
         when total_price <= 10000 then 'over $50 up to $100'
         when total_price <= 50000 then 'over $100 up to $500'
         when total_price <= 100000 then 'over $500 up to $1000'
         when total_price > 100000 then 'over $1000'
         else 'unknown' 
       end AS price_tier, 
       AVG(shipping_cost) AS avg_ship_cost,
       AVG(total_price - total_cost) AS avg_profit
FROM analyst.cart_shipping
GROUP BY price_tier;
