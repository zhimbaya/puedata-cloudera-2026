SELECT AVG(order_profit) AS avg_profit_per_order
FROM (SELECT SUM(price - cost) AS order_profit
      FROM analyst.products p
        JOIN analyst.order_details d ON d.prod_id = p.prod_id
        JOIN analyst.orders o ON d.order_id = o.order_id
      WHERE YEAR(order_date) = 2013 AND
            MONTH(order_date) = 5
      GROUP BY o.order_id) s;
