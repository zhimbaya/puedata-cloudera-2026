-- This will not run in Hive because the GROUP BY clause
-- uses an alias from the SELECT list. Use Impala to run
-- this query.

SELECT case
         when total_price <= 10000 then 'up to $100'
         when total_price <= 50000 then 'over $100 up to $500'
         when total_price <= 100000 then 'over $500 up to $1000'
         when total_price > 100000 then 'over $1000'
         else 'unknown' 
       end AS price_tier, 
       SUM(total_price - total_cost) AS total_profit
FROM analyst.cart_shipping
WHERE steps_completed = 4
GROUP BY price_tier;
