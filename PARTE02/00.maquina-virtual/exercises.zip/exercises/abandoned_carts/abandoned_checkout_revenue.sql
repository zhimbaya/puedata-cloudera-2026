SELECT SUM(total_price) AS lost_revenue 
FROM analyst.cart_shipping 
WHERE steps_completed < 4;
