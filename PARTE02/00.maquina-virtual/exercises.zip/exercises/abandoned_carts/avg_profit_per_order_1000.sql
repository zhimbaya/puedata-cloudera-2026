-- This will not run in Hive because the GROUP BY clause
-- uses an alias from the SELECT list. Use Impala to run
-- this query.

SELECT case 
         when order_price <= 1000 then 'up to $10'
         when order_price > 1000 then 'over $10'
         else 'unknown' 
       end AS price_tier, 
       AVG(order_profit) AS avg_profit_per_order
FROM 
  (SELECT SUM(price) as order_price,
               SUM(price - cost) AS order_profit
   FROM analyst.products p
     JOIN analyst.order_details d ON d.prod_id = p.prod_id
     JOIN analyst.orders o ON d.order_id = o.order_id
   WHERE YEAR(order_date) = 2013 AND
         MONTH(order_date) = 5
   GROUP BY o.order_id) s
GROUP BY price_tier;
