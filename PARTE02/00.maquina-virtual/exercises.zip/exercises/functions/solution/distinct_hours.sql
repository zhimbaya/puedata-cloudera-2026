SELECT DISTINCT hour(order_date) AS hour
  FROM analyst.orders
  ORDER BY hour ;
