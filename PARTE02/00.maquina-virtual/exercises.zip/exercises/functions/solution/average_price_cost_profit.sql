SELECT avg(price), avg(cost),
    avg(price - cost) AS avg_profit
  FROM analyst.products;
