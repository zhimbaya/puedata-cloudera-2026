USE analyst;

-- Checking each column separately
SELECT * FROM products WHERE price IS NULL;
SELECT * FROM products WHERE cost IS NULL;

SELECT * FROM products
  WHERE price IS NULL OR cost IS NULL;
