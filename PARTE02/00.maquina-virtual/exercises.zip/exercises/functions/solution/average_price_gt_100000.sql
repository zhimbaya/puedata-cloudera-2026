SELECT brand, round(avg(price)) avg_price, round(avg(cost)) avg_cost,
    round(avg(price - cost)) AS avg_profit
  FROM analyst.products GROUP BY brand
  HAVING avg(price) > 100000
  ORDER BY avg_price DESC ;
