SELECT brand, name, price FROM analyst.products
  WHERE price > (
    SELECT  round(avg(price)) avg_price
      FROM analyst.products GROUP BY brand
      HAVING avg(price) > 100000
      ORDER BY avg_price DESC
      LIMIT 1
  )
/*
SELECT brand, name, price
FROM (
  SELECT brand, name, price,
         ROUND(AVG(price) OVER(PARTITION BY brand)) as brand_avg
  FROM analyst.products
) t
WHERE price > brand_avg 
  AND brand_avg > 100000;
*/
