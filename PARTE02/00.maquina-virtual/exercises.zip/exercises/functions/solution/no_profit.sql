SELECT prod_id, brand, name, price, cost,
    price - cost AS profit
  FROM analyst.products WHERE price <= cost ;
