SELECT prod_id, brand, name, price - cost AS profit
  FROM analyst.products
  ORDER BY profit DESC
  LIMIT 5;
  