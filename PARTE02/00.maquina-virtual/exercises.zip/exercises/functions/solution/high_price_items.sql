SELECT brand, name, price FROM analyst.products
  WHERE price > 184237;
  