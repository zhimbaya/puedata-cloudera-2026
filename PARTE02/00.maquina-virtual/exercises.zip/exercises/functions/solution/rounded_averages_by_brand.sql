SELECT brand, round(avg(price)), round(avg(cost)),
    round(avg(price - cost)) AS avg_profit
  FROM analyst.products GROUP BY brand;
  