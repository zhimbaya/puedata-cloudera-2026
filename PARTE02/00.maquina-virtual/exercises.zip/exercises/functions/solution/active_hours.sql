-- Most active hours
SELECT hour(order_date) AS hour, COUNT(*) AS hr_count
  FROM analyst.orders
  GROUP BY hour(order_date)
  ORDER BY hr_count DESC
  LIMIT 3;

-- Least active hours
SELECT hour(order_date) AS hour, COUNT(*) AS hr_count
  FROM analyst.orders
  GROUP BY hour(order_date)
  ORDER BY hr_count
  LIMIT 3;
