SELECT brand, 
	MIN(if(price > cost,price/(price - cost),NULL)) AS min_ratio,
    MAX(if(price > cost,price/(price - cost),NULL)) AS max_ratio
  	FROM analyst.products 
	GROUP BY brand;
