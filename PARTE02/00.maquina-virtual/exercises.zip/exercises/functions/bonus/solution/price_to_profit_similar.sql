SELECT prod_id, brand, name, price, cost,
    price/(price - cost) AS ratio
  FROM analyst.products
  WHERE name LIKE '8GB%Dual Channel Desktop Memory Kit%';
