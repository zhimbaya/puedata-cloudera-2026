SELECT
  brand,
  MIN( if(price > cost,price/(price - cost), NULL) ) AS min_ratio,
  MAX( if(price > cost,price/(price - cost), NULL) ) AS max_ratio
FROM analyst.products 
GROUP BY brand
ORDER BY brand ;

SELECT
  brand,
  MIN( price/(price - cost) ) AS min_ratio,
  MAX( price/(price - cost) ) AS max_ratio
FROM analyst.products
WHERE price > cost
GROUP BY brand
ORDER BY brand ;
