SELECT prod_id, brand, name, price, cost,
    price/(price - cost) AS ratio
  FROM analyst.products
  WHERE price < cost
  ORDER BY ratio

UNION ALL

SELECT prod_id, brand, name, price, cost,
    price/(price - cost) AS ratio
  FROM analyst.products
  WHERE price >= cost
  ORDER BY ratio DESC
  LIMIT 10
