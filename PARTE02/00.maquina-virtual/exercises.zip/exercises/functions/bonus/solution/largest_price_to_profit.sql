SELECT prod_id, brand, name, price, cost,
    price/(price - cost) AS ratio
  FROM analyst.products
  ORDER BY ratio DESC
  LIMIT 10;
