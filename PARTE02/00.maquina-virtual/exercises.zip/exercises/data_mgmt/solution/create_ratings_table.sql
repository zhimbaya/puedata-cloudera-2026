-- This table is created using Hue in the exercise,
-- but it could be created using the command below

DROP TABLE IF EXISTS analyst.ratings;

CREATE TABLE analyst.ratings
   (posted TIMESTAMP, 
    cust_id INT,
    prod_id INT,
    rating TINYINT,
    message STRING)       
  ROW FORMAT DELIMITED 
    FIELDS TERMINATED BY '\t'
  STORED AS TEXTFILE;
