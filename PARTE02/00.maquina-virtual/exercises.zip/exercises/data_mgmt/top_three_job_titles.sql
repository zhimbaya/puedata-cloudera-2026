SELECT job_title, COUNT(*) AS num
    FROM analyst.employees 
    GROUP BY job_title 
    ORDER BY num DESC
    LIMIT 3;
