SELECT COUNT(*) FROM analyst.suppliers WHERE state='TX';
