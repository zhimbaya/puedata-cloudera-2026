#!/bin/bash

sqoop import \
  --connect jdbc:mysql://localhost/analyst_dualcore \
  --username training --password training \
  --fields-terminated-by '\t' \
  --table suppliers \
  --warehouse-dir /warehouse/tablespace/managed/hive/analyst.db/ \
  --delete-target-dir

# --delete-target-dir protects the import statement from failing if
# /warehouse/tablespace/managed/hive/analyst.db/suppliers already 
# exists, such as if you have already run this command once and you
# are running it again. If you know that directory does not already
# exist, that option can be omitted.
