ALTER TABLE analyst.suppliers CHANGE company name STRING;
