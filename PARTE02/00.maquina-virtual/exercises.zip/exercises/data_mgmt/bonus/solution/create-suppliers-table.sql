DROP TABLE IF EXISTS analyst.suppliers;

CREATE TABLE analyst.suppliers
    (supp_id int,
     company string,
     contact string,
     address string,
     city string,
     state string,
     zipcode string,
     phone string)
ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE;
