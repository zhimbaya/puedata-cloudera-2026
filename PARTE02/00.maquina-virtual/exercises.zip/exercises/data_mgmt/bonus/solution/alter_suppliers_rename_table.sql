ALTER TABLE analyst.suppliers RENAME TO vendors;
