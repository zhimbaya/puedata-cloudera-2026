SELECT
    display_site, display_date, num,
    LAG(num) OVER
      (PARTITION BY display_site ORDER BY display_date) AS nprev
  FROM (
    SELECT
        display_site, display_date,
        COUNT(display_date) AS num
      FROM analyst.ads
      GROUP BY display_site, display_date
    ) ads_count
  ORDER BY display_site, display_date;
