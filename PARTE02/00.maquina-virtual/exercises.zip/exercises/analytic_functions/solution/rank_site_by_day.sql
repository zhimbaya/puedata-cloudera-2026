SELECT display_site, display_date, num,
    RANK() OVER (PARTITION BY display_date ORDER BY num DESC) AS dayrank
  FROM (
    SELECT
        display_site, display_date,COUNT(display_date) AS num
      FROM analyst.ads
      GROUP BY display_site, display_date
    ) ads_count
  ORDER BY display_date, dayrank;
