SELECT display_site, display_date, num,
    round(
      AVG(num) OVER
        (PARTITION BY display_site ORDER BY display_date
         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
      , 2
    ) AS wavg
    FROM (
    SELECT
        display_site, display_date,
        COUNT(display_date) AS num
      FROM analyst.ads
      GROUP BY display_site, display_date
    ) ads_count
  ORDER BY display_site, display_date;
