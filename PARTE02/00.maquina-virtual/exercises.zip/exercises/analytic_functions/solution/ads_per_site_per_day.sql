SELECT
    display_site, display_date,
    COUNT(display_date) AS num
  FROM analyst.ads
  GROUP BY display_site, display_date;
