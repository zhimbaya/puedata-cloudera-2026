SELECT DISTINCT brand, med
  FROM
    (SELECT brand,
      FIRST_VALUE(price) OVER (PARTITION BY brand ORDER BY cd) AS med
      FROM
        (SELECT brand, price,
          CUME_DIST() OVER (PARTITION BY brand ORDER BY price) AS cd
          FROM analyst.products
        )x
      WHERE cd >=0.5
    ) y;
