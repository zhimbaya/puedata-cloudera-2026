SELECT price
    FROM
      (SELECT price,
        cume_dist() OVER (ORDER BY price) AS cd
        FROM analyst.products) x
    WHERE cd >= 0.5
    ORDER BY price
    LIMIT 1;
