SELECT cust_id, order_id
  FROM analyst.loyalty_program
    LATERAL VIEW explode(order_ids) o AS order_id
  WHERE order_value.avg > 90000;
