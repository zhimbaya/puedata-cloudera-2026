SELECT explode(order_ids)
  FROM analyst.loyalty_program
  WHERE cust_id=1200866;
