CREATE EXTERNAL TABLE analyst.loyalty_program_parquet
  STORED AS PARQUET
AS
  SELECT * from analyst.loyalty_program;
