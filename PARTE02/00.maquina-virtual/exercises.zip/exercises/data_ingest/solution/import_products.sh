#!/bin/bash

sqoop import \
 --connect jdbc:mysql://localhost/analyst_dualcore \
 --username training --password training \
 --fields-terminated-by '\t' \
 --warehouse-dir /analyst/dualcore \
 --table products
 