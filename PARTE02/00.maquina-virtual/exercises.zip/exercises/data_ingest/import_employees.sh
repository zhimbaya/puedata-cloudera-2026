#!/bin/bash

sqoop import \
 -Dorg.apache.sqoop.splitter.allow_text_splitter=true \
 --connect jdbc:mysql://localhost/analyst_dualcore \
 --username training --password training \
 --fields-terminated-by '\t' \
 --warehouse-dir /analyst/dualcore \
 --table employees
 