CREATE TEMPORARY TABLE analyst.order_details_orc
   (order_id INT, prod_id INT)
  STORED AS ORC;

CREATE TEMPORARY TABLE analyst.products_orc
   (prod_id INT, brand STRING,
    name STRING, price INT,
    cost INT, shipping_wt INT)
  STORED AS ORC;

INSERT INTO analyst.order_details_orc
   SELECT * FROM analyst.order_details SORT BY prod_id;

INSERT INTO analyst.products_orc
   SELECT * FROM analyst.products SORT BY prod_id;
