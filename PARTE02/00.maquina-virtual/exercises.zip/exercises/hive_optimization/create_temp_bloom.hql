CREATE TEMPORARY TABLE analyst.order_details_bloom
      (order_id INT, prod_id INT)
    STORED AS ORC
    TBLPROPERTIES ('orc.bloom.filter.columns'='prod_id');

INSERT INTO analyst.order_details_bloom 
    SELECT * FROM order_details;
