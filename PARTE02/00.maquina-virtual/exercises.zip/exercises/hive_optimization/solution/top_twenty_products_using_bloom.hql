SELECT name, brand, p.prod_id, num 
FROM analyst.products p 
  JOIN 
    (SELECT o.prod_id AS prod_id, COUNT(order_id) AS num
     FROM analyst.order_details_bloom o 
     WHERE o.order_id IN 
       (SELECT order_id 
        FROM analyst.order_details_bloom
        WHERE prod_id = 1274348)
     GROUP BY o.prod_id) x
    ON p.prod_id = x.prod_id
ORDER BY num DESC
LIMIT 20;
