SELECT name, brand, o.prod_id, num
FROM
 (SELECT prod_id, COUNT(prod_id) AS num
  FROM analyst.order_details_orc
  GROUP BY prod_id
  ORDER BY num DESC
  LIMIT 10 ) o
JOIN analyst.products_orc p ON o.prod_id = p.prod_id;
