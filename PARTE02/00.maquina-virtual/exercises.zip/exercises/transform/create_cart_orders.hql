DROP TABLE IF EXISTS analyst.cart_orders;
CREATE EXTERNAL TABLE analyst.cart_orders AS
   SELECT z.cookie, steps_completed, zipcode, 
          SUM(shipping_wt) as total_weight, 
          SUM(price) AS total_price, 
          SUM(cost) AS total_cost
   FROM analyst.cart_zipcodes z
     JOIN analyst.cart_items i
       ON (z.cookie = i.cookie)
     JOIN analyst.products p
       ON (i.prod_id = p.prod_id)
   GROUP BY z.cookie, zipcode, steps_completed;
