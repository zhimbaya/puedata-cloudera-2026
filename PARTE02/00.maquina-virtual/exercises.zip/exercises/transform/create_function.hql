DROP FUNCTION IF EXISTS analyst.calc_shipping_cost;
CREATE FUNCTION analyst.calc_shipping_cost 
   AS 'com.cloudera.hive.udf.UDFCalcShippingCost'
   USING JAR 'hdfs:/analyst/dualcore/geolocation_udf.jar';
