DROP TABLE IF EXISTS analyst.checkout_sessions;
CREATE EXTERNAL TABLE analyst.checkout_sessions AS
    SELECT cookie, ip_address, COUNT(request) AS steps_completed
    FROM analyst.web_logs 
    WHERE request REGEXP '/cart/checkout/step\\d.+'
    GROUP BY cookie, ip_address;
