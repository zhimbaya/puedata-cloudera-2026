DROP TABLE IF EXISTS analyst.cart_shipping;
CREATE EXTERNAL TABLE analyst.cart_shipping AS
    SELECT cookie, steps_completed, total_price, total_cost, 
          analyst.calc_shipping_cost(zipcode, total_weight) AS shipping_cost
    FROM analyst.cart_orders;
