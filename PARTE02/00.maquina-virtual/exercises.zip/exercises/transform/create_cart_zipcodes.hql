DROP TABLE IF EXISTS analyst.cart_zipcodes;
CREATE EXTERNAL TABLE analyst.cart_zipcodes AS
    SELECT TRANSFORM(cookie, ip_address, steps_completed)
        USING 'hdfs:/analyst/dualcore/ipgeolocator.py' AS (cookie STRING, zipcode STRING, steps_completed INT)
    FROM analyst.checkout_sessions;
