DROP TABLE IF EXISTS analyst.cart_items;
CREATE EXTERNAL TABLE analyst.cart_items AS
    SELECT cookie, 
           cast(regexp_extract(request, '/cart/additem\\?productid=(\\d+)', 1) 
                AS int) AS prod_id
    FROM analyst.web_logs
    WHERE request REGEXP '/cart/additem\\?productid=(\\d+)';
