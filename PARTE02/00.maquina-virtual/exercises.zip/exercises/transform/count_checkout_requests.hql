SELECT COUNT(*), request 
FROM analyst.web_logs 
WHERE request REGEXP '/cart/checkout/step\\d.+'
GROUP BY request;
