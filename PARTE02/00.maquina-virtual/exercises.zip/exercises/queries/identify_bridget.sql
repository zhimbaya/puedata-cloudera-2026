SELECT *
  FROM analyst.customers 
 WHERE fname LIKE 'Bridg%'
   AND city = 'Kansas City';
