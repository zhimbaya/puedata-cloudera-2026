SELECT *
  FROM analyst.products
  ORDER BY price DESC
  LIMIT 3;
