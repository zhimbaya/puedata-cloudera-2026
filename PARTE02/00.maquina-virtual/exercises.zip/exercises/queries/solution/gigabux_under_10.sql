SELECT * 
  FROM analyst.products 
  WHERE brand='Gigabux' AND price < 1000;