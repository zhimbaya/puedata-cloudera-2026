-- Note: Whether p.prod_id should be included in the GROUP BY
-- is arguable. There are items in the products table with 
-- the same brand and name but different prod_id, and different
-- price and cost. Whether these should be kept separate or
-- combined is a matter of interpretation.

SELECT brand, name, COUNT(p.prod_id) AS sold 
  FROM analyst.products p
    JOIN analyst.order_details d
      ON (p.prod_id = d.prod_id)
  GROUP BY brand, name, p.prod_id
  ORDER BY sold DESC
  LIMIT 3;
