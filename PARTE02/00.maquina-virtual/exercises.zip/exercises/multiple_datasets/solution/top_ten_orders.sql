SELECT od.order_id, SUM(p.price) AS total 
  FROM analyst.order_details od
    JOIN analyst.products p 
      ON (od.prod_id = p.prod_id)
  GROUP BY order_id 
  ORDER BY total DESC
  LIMIT 10;
