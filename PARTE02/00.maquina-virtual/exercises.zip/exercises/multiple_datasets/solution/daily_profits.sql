SELECT to_date(order_date) as o_date, SUM(price) AS revenue, SUM(price - cost) as profit
  FROM analyst.products p
    JOIN analyst.order_details d
      ON (p.prod_id = d.prod_id)
    JOIN analyst.orders o
      ON (d.order_id = o.order_id)
  GROUP BY to_date(order_date)
  ORDER BY o_date;
