SELECT
    to_date(order_date) AS date_ordered,
    sum(price-cost) AS profit
  FROM analyst.orders o
    JOIN analyst.order_details d
      ON o.order_id = d.order_id
    JOIN analyst.products p
      ON d.prod_id = p.prod_id
  GROUP BY to_date(order_date)
  LIMIT 20;
