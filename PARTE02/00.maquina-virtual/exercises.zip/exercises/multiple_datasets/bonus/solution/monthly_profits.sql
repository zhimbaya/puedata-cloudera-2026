SELECT
    month( order_date ) AS month,
    year( order_date ) as year,
    SUM( price-cost ) AS profit
  FROM analyst.orders o
    JOIN analyst.order_details d
      ON o.order_id = d.order_id
    JOIN analyst.products p
      ON d.prod_id = p.prod_id
  GROUP BY year(order_date), month(order_date)
  ORDER BY year, month ;
