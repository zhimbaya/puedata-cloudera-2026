-- Most profitable months
SELECT
    month( order_date  ) AS month,
    year( order_date ) as year,
    SUM( price-cost ) AS profit
  FROM analyst.orders o
    JOIN analyst.order_details d
      ON o.order_id = d.order_id
    JOIN analyst.products p
      ON d.prod_id = p.prod_id
  GROUP BY month( order_date ), year( order_date )
  ORDER BY profit DESC
  LIMIT 4;

-- Least profitable months
SELECT
    month( order_date ) AS month,
    year( order_date ) as year,
    SUM( price-cost ) AS profit
  FROM analyst.orders o
    JOIN analyst.order_details d
      ON o.order_id = d.order_id
    JOIN analyst.products p
      ON d.prod_id = p.prod_id
  GROUP BY month( order_date ), year( order_date )
  ORDER BY profit ASC
  LIMIT 4;
