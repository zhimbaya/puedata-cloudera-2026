SELECT
    to_date(order_date) AS date_ordered,
    sum(price-cost) AS profit
  FROM analyst.orders o
    JOIN analyst.order_details d
      ON o.order_id = d.order_id
    JOIN analyst.products p
      ON d.prod_id = p.prod_id
  GROUP BY to_date(order_date)
    HAVING cast(to_date(order_date) AS STRING)
      BETWEEN '2013-05-01' AND '2013-05-31'
  ORDER BY date_ordered;
