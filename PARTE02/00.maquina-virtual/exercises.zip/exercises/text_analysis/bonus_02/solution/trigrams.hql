SELECT explode(ngrams(sentences(lower(message)), 3, 5)) 
        AS trigrams 
    FROM analyst.ratings
    WHERE prod_id = 1274673;
