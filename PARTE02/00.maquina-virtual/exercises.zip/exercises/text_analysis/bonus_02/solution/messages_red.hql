SELECT DISTINCT message
    FROM analyst.ratings 
    WHERE prod_id = 1274673 AND lower(message) LIKE '%red%'; 
