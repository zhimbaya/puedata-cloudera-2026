SELECT * FROM analyst.products WHERE prod_id=1274673;
