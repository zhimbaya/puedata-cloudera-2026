SELECT *
    FROM analyst.products 
    WHERE name LIKE '%16 GB USB Flash Drive%' 
       AND brand='Orion';
