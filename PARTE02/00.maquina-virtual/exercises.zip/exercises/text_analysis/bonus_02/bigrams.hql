SELECT explode(ngrams(sentences(lower(message)), 2, 5)) 
        AS bigrams 
    FROM analyst.ratings
    WHERE prod_id = 1274673;
