SELECT term, COUNT(term) AS num FROM
   (SELECT lower(regexp_extract(request,
       '/search\\?phrase=(\\S+)', 1)) AS term
       FROM analyst.web_logs
       WHERE request REGEXP '/search\\?phrase=') term
  GROUP BY term
  ORDER BY num DESC
  LIMIT 3;
  